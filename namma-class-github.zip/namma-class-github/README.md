# Namma Class

A mobile-friendly self-learning website for school students. This GitHub-ready starter includes:
- Subject and lesson selection for Class 1
- Read-aloud using the browser's speech synthesis
- Short quizzes with feedback
- Local-device lesson progress
- Three simple learning games
- A responsive layout for phones and computers

## Run locally
You can open `public/index.html` directly, or use VS Code's Live Server extension.

## Publish with GitHub Pages
1. Create a GitHub repository named `namma-class`.
2. Upload the files while preserving the `public/` folder.
3. In repository **Settings → Pages**, choose **Deploy from a branch**.
4. Choose `main` and `/ (root)` only if you move the contents of `public/` to the repository root. Otherwise use a GitHub Actions workflow to publish the `public` folder.
5. Easiest option: move `index.html`, `style.css`, and `app.js` from `public/` to the repository root, then select `main` / `root` in Pages.

## Important
This is a static front-end starter, not a copy of the private Hatchable source. Textbook PDF embeds, full original curriculum, and all existing Hatchable implementation details should be added/checked separately. Lesson progress is stored in the browser on that device only. No backend or login is included.
